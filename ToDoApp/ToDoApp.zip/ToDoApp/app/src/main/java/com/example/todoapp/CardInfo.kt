package com.example.todoapp

data class CardInfo(
    var title:String,
    var priority:String
)